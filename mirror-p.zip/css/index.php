<?php 
echo "Forbidden";
?>