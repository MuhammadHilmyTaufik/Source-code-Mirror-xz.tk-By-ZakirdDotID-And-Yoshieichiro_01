</div>
<footer>      
 <p></p>
 <center><a href="/index" class="btn btn-danger">Home || Beta Version</a></center>      
 <p></p>
 </footer>
 <script src="/js/vendor/bootstrap.min.js"></script>
 <script src="/js/plugins.js"></script>
 </body>
 </html>