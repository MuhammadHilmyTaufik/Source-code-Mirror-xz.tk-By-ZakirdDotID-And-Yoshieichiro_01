<?php include('inc/config.php'); 
session_start();
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js"  lang="en"> <!--<![endif]-->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo site_title; ?> - Go To Hell</title>
        <meta name="description" content="Mirror Deface | Unrestricted information | professional mirror platform | Deface Notify Mirror | Notify Defacements | Ind Cyber Portal | Mirror Service | Mass Notifier | Add Deface | Add Attack | Cyber Community | Add your Deface | Hack Zone | Cyber Community">
        <meta name="viewport" content="width=device-width">
        <meta name="description" content="Mirror-DB.com Mirror is a Site to Save Defacement And All Hacker Hacktivities And Store Unrestertied Info Of Hackers !,- A global view to the world with a stress on the ITsec, pakistani, Notifier, Add your Deface , Deface, Hacked , Report Your Attack, Hackers, Ranking , Hacker, Attackers, Mirror, Web, Zone, India Web Hack, Russia, Turkey, USA, Got, Who, Pro, Cyber, Media">
        <meta content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET,  Googlebot" name="search engines">
        <meta name="keywords" content="Mirror-DB, MirrorDB, Mirror-DB, mirror-DB, hacker course,  seminar,seminario,security seminar,security course,securityfocus,penetration test,antivirus,antispam,hack inside,defacement,defacements,hacker,hackers,cracker,crackers,defacer,defacers,security,advisory,advisories,news,it,itsec,information,technology,defaced,attacks,cybercrime,attacks archive,attack,cyberterrorism,sql injection,buffer overflow,stack overflow,heap overflow,file inclusion,directory traversal, terrorism, counter terrorism, intelligence,geopolitic, Add Mirror, Notify Mirror, ZoneDB, HackDB, ZoneH, Hackers, Mirror, Deface, HackerZone, Add Notify, Mirror Zone, WebNotify,Skype Resolver,pakistani, Notifier, Add , Deface, Hacked , Report Your Attack, Hackers, Ranking , Hacker, Attackers, Mirror, Web, Zone, India Web Hack, Russia, Turkey, USA, Got, Who, Pro, Cyber, Media, Mass Deface , Notify Mass Defacements, Notify Mass Defacemnts, Notify mass Deface, Mass Notify Script, zone-db.com mass notify script,  Defacements, War,zone kayit,deface add, add, hack-h, hack add, Mirror Kayit, Zone Kayit ,Zone Kaydet ,Deface Kayit , mirror kayit,mirror zone,deface kayit,">
        <link rel="stylesheet" href="<?php echo url_site; ?>css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo url_site; ?>library/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo url_site; ?>css/main.css">
        <script src="<?php echo url_site; ?>js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
        <![endif]-->
            <div class="container">
            <!-- Page Header -->     
            <img src="img/banne.jpg" height="136" width="1140" class="img-responsive" "></center>
            <div class="navbar navbar-inverse navbar-default">
                <!--<div class="container">-->
                <div class="navbar-header visible-xs">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">                       <li>
                        <a href="index.php"><span class="fa fa-desktop"></span> <span class="xn-text">Home</span></a>
                            </a>
                        </li>
                     <li>
                            <a href="single.notify"><span class="fa fa-plus-square"></span> <span class="xn-text">
                                 Notify</span>
                            </a> 
                        </li>
                       <li>
                            <a href="mass.notify"><span class="fa fa-pencil"></span><span class="xn-text">
                                Mass</span>
                            </a> 
                        </li>
                        <li>
                            <a href="archive/1"><span class="fa fa-book"></span> <span class="xn-text">
                              Attacks Archive </span>
                            </a> 
                        </li>
                        <li>
                            <a href="special/1"><span class="fa fa-star-half-empty"></span> <span class="xn-text">
                                 Special Archive </span>
                            </a>
                        </li>
                        <li>
                            <a href="onhold/1"><span class="fa fa-thumb-tack"></span> <span class="xn-text">
                                 Onholds Archive </span>
                            </a>
                        </li>
                        <li>
                            <a href="ranked/1"><span class="fa fa-trophy"></span> <span class="xn-text">
                                Attacker Ranking </span>
                            </a>
                        </li>
                        <li>
                            <a href="team/ranked/1"><span class="fa fa-signal"></span> <span class="xn-text">
                                Team Ranking </span>
                            </a>
                        </li>
        </ul>                            
                        </li>
                    </ul>
                                    </div><!--/.navbar-collapse -->
                <!--</div>-->
            </div>
            <div class=" alert alert-danger">
                <?php echo TampilPesan();
                ?>
            </div>