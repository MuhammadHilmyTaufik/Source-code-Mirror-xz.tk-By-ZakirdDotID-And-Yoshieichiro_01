<?php
ob_start();
/**
 * Script Design By D34D ZoNe
 *
 */

define('db_host','localhost'); //hostname
define('db_name','dbanmehere'); //database_name
define('db_uname',	'dbuserhere'); //username
define('db_pass','urdbpassword'); //password



if(file_exists('mysql.class.php'))
{
    require_once('mysql.class.php');
    require_once('lib.php');
    require_once('paging.php');
} elseif(file_exists('inc/mysql.class.php'))
{
    require_once('inc/mysql.class.php');
    require_once('inc/lib.php');
    require_once('inc/paging.php');
} elseif(file_exists('../inc/mysql.class.php'))
{
    require_once('../inc/mysql.class.php');
    require_once('../inc/lib.php');
    require_once('../inc/paging.php');
} elseif(file_exists('../../inc/mysql.class.php'))
{
    require_once('../../inc/mysql.class.php');
    require_once('../../inc/lib.php');
    require_once('../../inc/paging.php');
} elseif(file_exists('../../../inc/mysql.class.php'))
{
    require_once('../../../inc/mysql.class.php');
    require_once('../../../inc/lib.php');
    require_once('../../../inc/paging.php');
} else
    die('Error: Tidak bisa load komponen files');


$db = new mysql(db_host, db_name, db_uname, db_pass);


$db->go("SELECT * FROM uadmin WHERE id = 1");
$data = $db->fetchArray();

define('admin_uname',   $data['uname']);
define('admin_password',    $data['password']);
define('admin_name',    $data['fname']);

$db->go("SELECT * FROM setting");
$setting = $db->fetchArray();

define('url_site',  'http://localhost/');
define('url_image_berita',  url_site.'uploads/image/berita');
define('site_title',    $setting['title']);
define('site_subtitle',    $setting['subtitle']);
define('site_description',    $setting['description']);
define('site_logo',     $setting['logo']);
define('site_hal',      $setting['jum_hal']);
$LOAD_RESULTS_OVERRIDE = false;
?>