<?php 
include "header.php";
?> 
<div class="col-md-12"><h3 class="section-title first-title"><center><span class="fa fa-code"></span> <b>Statistics</b></center></h3>
 <div class="widget-content-white glossed">
        <div class="padded">
            <table class="table table-striped table-bordered table-hover datatable">
                <thead>
                    <tr>
                        <th class="text-center">Total Hacker</th>
                        <th class="text-center">Total Team</th>
                        <th class="text-center">Total Deface</th>
                        <th class="text-center">Total Deface in Attack Archive</th>                                       
                        <th class="text-center">Total Special Deface </th>
                        <th class="text-center">Total Attack Onholds</th>
                    </tr>
                </thead>
                    <tbody>
                        <tr>   <?php
                        $db->go("SELECT * FROM hacker");
                        $data = $db->numRows();
                        ?>                  
                            <td class="text-center" ><?php echo $data; ?></a></td>
 <?php
                        $db->go("SELECT * FROM team");
                        $data = $db->numRows();
                        ?>                    

                            <td class="text-center"><?php echo $data; ?></td>
<?php
                        $db->go("SELECT * FROM notify");
                        $data1 = $db->numRows();
                        ?>          
                        <td class="text-center"><?php echo $data1; ?></td>
<?php
                        $db->go("SELECT * FROM notify  WHERE status = 1");
                        $data3 = $db->numRows();
                        ?>            <td class="text-center"><?php echo $data3; ?></td>
<?php
                    				 $db->go("SELECT * FROM notify WHERE status = 1 AND type = 1");
                        $data1 = $db->numRows();
                        ?>           <td class="text-center"><?php echo $data1; ?></td>

<?php
                $db->go("SELECT * FROM notify WHERE status = 0");
                        $data2 = $db->numRows();
                                                ?>            <td class="text-center"><?php echo $data2; ?></td>

                            </tr>
                    </tbody>
                </table>
        </div>
    </div>
</div>
<div class="col-md-6"><h3 class="section-title first-title"><center><span class="fa fa-trophy"></span> <b>Top 5 Hacker</b></center></h3>
 <div class="widget-content-white glossed">
        <div class="padded">
            <table class="table table-striped table-bordered table-hover datatable">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Team Name</th>
                        <th>Total Deface</th>
                        <th>Special Deface</th>
                    </tr>
                </thead>
                <?php
                $db->go("SELECT * FROM hacker ORDER BY deface DESC LIMIT 5");
                $no = 1;
                while ($data = $db->fetchArray()) {
                    ?>
                    <tbody>
                        <tr>
                            <td><?php echo $no; ?></a></td>
                            <td class="text-center"><a href="<?php echo url_site; ?>hacker/<?php echo $data['hacker']; ?>/1"><?php echo htmlspecialchars($data['hacker']); ?></a></td>
                            <td class="text-center"><?php echo htmlspecialchars($data['team']); ?></td>
                            <td class="text-center"><?php echo $data['deface']; ?></a></td>
                            <td class="text-center"><?php echo $data['special']; ?></td>
                        </tr>
                    </tbody>
    <?php $no++;
} ?>
        </table>
    </div>
</div>
</div>
<div class="col-md-6"><?php include "atop5.php"; ?>
</div>
<div class="col-md-12"><?php include "recent.php"; ?>
</div>
<div class="col-md-12"><?php include "reon.php"; ?>
</div>
<?php
include "footer.php"; 
?>