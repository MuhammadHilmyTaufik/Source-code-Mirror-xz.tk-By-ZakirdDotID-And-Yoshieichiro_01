<?php
include('header.php');
$id = NoSqli($_GET['id']);
$db->go("SELECT * FROM notify WHERE id = '$id'");

$control = $db->numRows();

if ($control == 0) {
    TambahPesan("Catatan tidak ada. Silahkan periksa kembali");
    Redirect('/archive.html?search=1');
} else {
    $db->go("SELECT * FROM notify WHERE id = '$id'");
    $mirror = $db->fetchArray();
    ?>
    <center><h3> View <span class="fa fa-eye"></span> Mirror : <strong>
        <?php echo'' . $mirror['url'] . ' ' ?></strong>   </h3></center>
      <?php
        if ($ip = $mirror['serip']) {
           	$ipdetail = json_decode(file_get_contents("http://ip-api.com/json/$ip"));
			$cn = $ipdetail->country;
			$cc = $ipdetail->countryCode;
			}
          ?>
    <div class="widget-content-white glossed">
        <div class="padded">
            <table class="table table-striped table-bordered table-hover datatable">
                <thead>
                    <tr>
                        <th class="text-center">Notified on</th>
                        <th class="text-center">Notified by</th>
                        <th class="text-center">Domain</th>           
                        <th class="text-center">PoC</th>
                        <th class="text-center">Server IP</th>
                        <th class="text-center">L</th>
                        <th class="text-center">Full Screen</th>
                    </tr>
                </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">
                                <strong> 
                                <?php echo' ' . $mirror['tanggal'] . ' ' ?>
                                </strong></td>
                            <td class="text-center">
                                <strong>
                                <?php echo' ' . htmlspecialchars($mirror['hacker']) . ' ' ?>
                                </strong></td>
                            <td class="text-center">
                                <strong>
                                <?php echo' ' . htmlspecialchars($mirror['url']) . ' ' ?>
                                </strong></td>
                            <td class="text-center"> 
                                <strong>
                                    <?php echo' ' . htmlspecialchars($mirror['poc']) . ' ' ?>
                                    </strong></td>
                            <td class="text-center"> 
                                <strong>
                                    <?php echo' ' . $mirror['serip'] . ' ' ?></strong></td>
                            <td class="text-center"> 
                                <img src='/flags/<?php echo $cc; ?>.png' alt='<?php echo $cn; ?>' title='<?php echo $cn; ?>'>
                                <?php echo $cnn; ?>
                            </td>
                            <td class="text-center"><strong>
                                <?php echo " <a href='".url_site."view/{$id}'  class='btn btn-success btn-xs' <i class='icon-external-link-sign'></i> View </a> " ?>
                                </strong>
                            </td>
                        </tr>
                    </tbody></table></div>
<div class="well"><iframe src= "<?php url_site; ?>inc/chack.php?id=<?php echo $_GET['id']; ?>" style="border:0px #000000 none;" width="100%" height="450px" border="0" scrolling="auto" frameborder="no"/></iframe>
</div>
</div>
<?php } ?>
<?php include "footer.php"; ?>