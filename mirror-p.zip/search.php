<?php
include('header.php');
?>
<div class="widget">
    <h3 class="section-title first-title"><i class="icon-table"></i> Notify Results</h3>
    <div class="widget-content-white glossed">
        <div class="padded">
            <?php
            $value = NoSqli($_POST['search']);
            if ((isset($value)) AND ($value <> "")) {

                $db->go("SELECT * FROM notify WHERE url LIKE '%$value%'");
                $hit1 = $db->numRows();

                if ($hit1 > 0) {
                    $db->go("SELECT * FROM notify WHERE url LIKE '%$value%'");
                    while ($data = $db->fetchArray()) {
                        echo '<p><a href="' . $data['url'] . '">' . $data['url'] . '</a> Notified By <strong>' . $data['hacker'] . '</strong><hr/>';
                    }
                } else {
                    echo '<p><strong>Data tidak ditemukan di database notify</strong></p>';
                }
                ?>
            </div>
        </div>
    </div>
    <?php
} else {
    TambahPesan("Anda belum menginputkan data apapun");
    Redirect('index');
}
include('footer.php');
?>