<?php
include('header.php');
$site_hal = site_hal;
if (isset($_GET['s'])) {
    $noS = $_GET['s'];
}
else
    $noS = 1;
$offset = ($noS - 1) * $site_hal;
?>
<div class="widget">
    <h3 class="section-title first-title"><center><span class="fa fa-star-half-empty"></span> <b>Special Archive</b></center></h3>
    <div class="widget-content-white glossed">
        <div class="padded">
            <table class="table table-striped table-bordered table-hover datatable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Domain</th>
                        <th class="text-center">H</th>
                        <th class="text-center">L</th>
                        <th class="text-center">IP</th>
                        <th class="text-center"><i class="fa fa-star"></i></th>
                        <th class="text-center">Time</th>
                        <th class="text-center">Mirror</th>
                    </tr>
                </thead>
                <?php
                $db->go("SELECT * FROM notify WHERE status = 1 AND type = 1 ORDER BY tanggal DESC LIMIT $offset , $site_hal");
                while ($dat = $db->fetchArray()) {

                    if (strlen($dat['url']) > 45) {
                        $url = substr($dat['url'], 0, 45) . "...";
                    } else {
                        $url = $dat['url'];
                    }

			$getHome = parse_url($dat['url'], PHP_URL_PATH);
			if($getHome=="/" || $getHome=="/index.php" || $getHome=="/index.html" || $getHome=="/index.htm" || $getHome=="" ) {
			$cekHome = 'H';
			} else {
			$cekHome = '';
			}
            if ($ip = $dat['serip']) {
			$ipdetail = json_decode(file_get_contents("http://ip-api.com/json/$ip"));
			$cn = $ipdetail->country;
			$cc = $ipdetail->countryCode;
			}
			if ($dat['type'] == "1" && $dat['status'] == "1") {
			$cekSpecial = '<i class="fa fa-star"></i>';
			}
			else {
			$cekSpecial = '<i class="fa fa-star-o"></i>';
			}					
                    ?>
                    <tbody>
                        <tr>
                            <td class="text-center">
                                <a href="<?php echo url_site; ?>hacker/<?php echo $dat['hacker']; ?>/1"><?php echo htmlspecialchars($dat['hacker']); ?></a></td>
                            <td><a href="<?php echo $dat['url']; ?>"><?php echo $url; ?></a></td>
                            <td class="text-center"><?php echo $cekHome; ?></td>
                            <td class="text-center"><img src='/flags/<?php echo $cc; ?>.png' alt='<?php echo $cn; ?>' title='<?php echo $cn; ?>'></td>
                            <td class="text-center"><?php echo $dat['serip']; ?></a></td>
                            <td class="text-center">
                                <?php echo $cekSpecial; ?></td>
                            <td class="text-center"><?php echo $dat['tanggal']; ?></td>
                            <td class="text-center">
                                <a href="<?php echo url_site; ?>mirror/<?php echo $dat['id']; ?>" class="btn btn-danger btn-xs"><i class="icon-external-link-sign"></i> Mirror</a>
                            </td>
                        </tr>
                    </tbody>
<?php } ?>
</table>
</div>
</div>
</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="pull-right">
                <div class="dataTables_paginate paging_bootstrap">
                    <ul class="pagination pagination-sm">
                        <?php
                        $db->go("SELECT COUNT(*) AS jumData FROM notify WHERE status = 1 AND type = 1");
                        $data = $db->fetchArray();

                        $jumData = $data['jumData'];
                        $jumPage = ceil($jumData / $site_hal);
                        // menampilkan link previous

                        if ($noS > 1)
                            echo "<li class='prev'><a href='".url_site."special/" . ($noS - 1) . "'> Prev</a></li>";

                        for ($page = 1; $page <= $jumPage; $page++) {
                            if ((($page >= $noS - 3) && ($page <= $noS + 3)) || ($page == 1) || ($page == $jumPage)) {
                                if (($showPage == 1) && ($page != 2))
                                    echo "";
                                if (($showPage != ($jumPage - 1)) && ($page == $jumPage))
                                    echo "";
                                if ($page == $noPage)
                                    echo " <li><a>" . $page . "</a></li> ";
                                else
                                    echo " <li><a href='".url_site."special/" . $page . "'>" . $page . "</a></li> ";
                                $showPage = $page;
                            }
                        }

                        // menampilkan link next

                        if ($noS < $jumPage)
                            echo "<li class='next'><a href='".url_site."special/" . ($noS + 1) . "'>Next </a></li>";
                        ?>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>
       </div>
   </div>
<?php include('footer.php'); ?>